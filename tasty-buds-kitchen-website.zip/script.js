const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
});
document.querySelectorAll(".nav a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
}));
document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("order-form").addEventListener("submit", event => {
  event.preventDefault();
  const name = document.getElementById("customer-name").value.trim();
  const details = document.getElementById("order-details").value.trim();
  const service = document.getElementById("service-type").value;
  const message = `Hello Tasty Buds Kitchen!%0AName: ${encodeURIComponent(name)}%0AService: ${encodeURIComponent(service)}%0AOrder / enquiry: ${encodeURIComponent(details)}`;
  window.open(`https://wa.me/918454002648?text=${message}`, "_blank", "noopener");
});