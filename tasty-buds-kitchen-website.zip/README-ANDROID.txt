TASTY BUDS KITCHEN WEBSITE - ANDROID PUBLISHING GUIDE

Your website files are:
- index.html (website content)
- style.css (design)
- script.js (menu and WhatsApp enquiry form)

IMPORTANT:
- The website uses the phone number +91 84540 02648.
- The order form sends an enquiry to WhatsApp. It does not take online payment or automatically confirm orders.
- Menu, cuisine, prices and opening hours are not filled in because they have not been confirmed.
- Replace the sample gallery tiles with real restaurant/food photos later if you wish.

PUBLISH USING ANDROID + GITHUB + NETLIFY:
1. Open Chrome and go to https://github.com/ and sign in / create a free account.
2. Create a new repository. Name it tasty-buds-kitchen. Set it to Public. Create repository.
3. In the repository, tap Add file > Upload files.
4. Upload index.html, style.css and script.js from this ZIP after extracting it. Upload the three files into the main/root of the repository (not inside another folder).
5. Tap Commit changes.
6. Open https://app.netlify.com/ and sign in.
7. Choose Add new project / Import an existing project, then choose GitHub.
8. Authorize Netlify to access the repository and select tasty-buds-kitchen.
9. For a simple HTML website, leave build command and publish directory empty if Netlify allows it; otherwise set publish directory to ".". Deploy.
10. Netlify will give you a website address ending in netlify.app. Open it to check your website.

If GitHub's mobile upload screen does not let you select all three files, upload them one at a time using Add file > Upload files. Keep all three in the repository root.

You can later change the website by editing the files in GitHub; Netlify will redeploy after you commit changes.
